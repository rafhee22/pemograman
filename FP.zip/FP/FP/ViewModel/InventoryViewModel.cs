﻿using System;
using System.Threading.Tasks;
using System.ComponentModel;
using System.Collections.ObjectModel;
using System.Data.SqlClient;
using System.Windows;
using FP.Setup;
using FP.Models;


namespace FP.ViewModel
{
    public class InventoryViewModel : INotifyPropertyChanged
    {
        public InventoryViewModel()
        {
            collection = new ObservableCollection<Inventory>();
            dbconn = new Db_Connection();
            model = new Inventory();


            SelectCommand = new RelayCommand(async () => await ReadDataAsync());
            UpdateCommand = new RelayCommand(async () => await UpdateDataAsync());
            DeleteCommand = new RelayCommand(async () => await DeleteDataAsync());
            SelectCommand.Execute(null);

        }
        public RelayCommand SelectCommand { get; set; }
        public RelayCommand UpdateCommand { get; set; }
        public RelayCommand DeleteCommand { get; set; }
        public ObservableCollection<Inventory> Collection
        {
            get
            {
                return collection;
            }
            set
            {
                collection = value;
                PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(null));
            }

        }

        public Inventory Model
        {
            get
            {
                return model;
            }
            set
            {
                if (value != null)
                {
                    IsChecked = (value.Status == "Active") ? true : false;
                }
                model = value;
                PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(null));
            }
        }
        public bool IsChecked
        {
            get
            {
                return check;
            }
            set
            {
                check = value;
                PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(null));

            }
        }



        public event PropertyChangedEventHandler PropertyChanged;
        public event Action OnCallBack;

        private readonly Db_Connection dbconn;
        private ObservableCollection<Inventory> collection;
        private Inventory model;
        private bool check;

        private async Task ReadDataAsync()
        {
            dbconn.OpenConnection();

            await Task.Delay(0);
            var query = "SELECT * FROM vinventories";
            var sqlcmd = new SqlCommand(query, dbconn.SqlConnection);
            var sqlresult = sqlcmd.ExecuteReader();

            if (sqlresult.HasRows)
            {
                Collection.Clear();
                while (sqlresult.Read())
                {
                    Collection.Add(new Inventory
                    {
                        Uid = sqlresult[0].ToString(),
                        LogDate = sqlresult[1].ToString(),
                        Users = sqlresult[2].ToString(),
                        Type = sqlresult[2].ToString(),
                        Status = (sqlresult[3].ToString() == "1") ?
                        "Active" : "Not Active",
                    });
                }
            }
            dbconn.CloseConnection();
            OnCallBack?.Invoke();
        }

        private async Task UpdateDataAsync()
        {
            if (isValidating())
            {
                dbconn.OpenConnection();
                var state = check ? "1" : "0";
                var query = $"UPDATE vinventories SET " +
                            $"Code = '{model.Uid}'," +
                            $"LogDate = '{model.LogDate}'," +
                            $"Users = '{model.Users}'," +
                            $"Type = '{model.Type}'," +
                            $"status = '{model.Status}'" +
                            $"WHERE Code = '{model.Uid}'";
                var sqlcmd = new SqlCommand(query, dbconn.SqlConnection);
                sqlcmd.ExecuteNonQuery();
                dbconn.CloseConnection();
                await ReadDataAsync();
            }
        }

        private async Task DeleteDataAsync()
        {
            if (isValidating())
            {
                var msg = MessageBox.Show("Are you sure?", "Question",
                          MessageBoxButton.YesNo, MessageBoxImage.Question);
                if (msg == MessageBoxResult.Yes)
                {
                    dbconn.OpenConnection();
                    var query = $"DELETE vinventory " +
                                $"WHERE Code = '{model.Uid}'";
                    var sqlcmd = new SqlCommand(query, dbconn.SqlConnection);
                    sqlcmd.ExecuteNonQuery();
                    dbconn.CloseConnection();
                }

                await ReadDataAsync();

            }
        }


        private bool isValidating()
        {
            var flag = true;

            return flag;
        }
    }
}


