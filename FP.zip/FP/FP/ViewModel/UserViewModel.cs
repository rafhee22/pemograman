﻿using System;
using System.Threading.Tasks;
using System.ComponentModel;
using System.Collections.ObjectModel;
using System.Data.SqlClient;
using System.Windows;
using FP.Setup;
using FP.Models;


namespace FP.ViewModel
{
    public class UserViewModel : INotifyPropertyChanged
    {
        public UserViewModel()
        {
            collection = new ObservableCollection<User>();
            dbconn = new Db_Connection();
            model = new User();


            SelectCommand = new RelayCommand(async () => await ReadDataAsync());
            UpdateCommand = new RelayCommand(async () => await UpdateDataAsync());
            DeleteCommand = new RelayCommand(async () => await DeleteDataAsync());

            SelectCommand.Execute(null);

        }
        public RelayCommand SelectCommand { get; set; }
        public RelayCommand UpdateCommand { get; set; }
        public RelayCommand DeleteCommand { get; set; }

        public ObservableCollection<User> Collection
        {
            get
            {
                return collection;
            }
            set
            {
                collection = value;
                PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(null));
            }

        }

        public User Model
        {
            get
            {
                return model;
            }
            set
            {
                if (value != null)
                {
                    IsChecked = (value.Status == "Active") ? true : false;
                }
                model = value;
                PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(null));
            }
        }
        public bool IsChecked
        {
            get
            {
                return check;
            }
            set
            {
                check = value;
                PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(null));

            }
        }



        public event PropertyChangedEventHandler PropertyChanged;
        public event Action OnCallBack;

        private readonly Db_Connection dbconn;
        private ObservableCollection<User> collection;
        private User model;
        private bool check;

        private async Task ReadDataAsync()
        {
            dbconn.OpenConnection();

            await Task.Delay(0);
            var query = "SELECT * FROM Users";
            var sqlcmd = new SqlCommand(query, dbconn.SqlConnection);
            var sqlresult = sqlcmd.ExecuteReader();

            if (sqlresult.HasRows)
            {
                Collection.Clear();
                while (sqlresult.Read())
                {
                    Collection.Add(new User
                    {
                        Uid = sqlresult[0] as int? ?? 0,
                        Name = sqlresult[1].ToString(),
                        UserName = sqlresult[2].ToString(),
                        Keypass = sqlresult[3].ToString(),
                        Status = (sqlresult[4].ToString() == "1") ?
                        "Active" : "Not Active",
                    });
                }
            }


            dbconn.CloseConnection();
            OnCallBack?.Invoke();
        }

        public bool Login()
        {
            bool status;
            if (Collection.Count > 0)
            {
                Collection.Clear();
            }
            dbconn.OpenConnection();
            var query = $"select * from Users where username='{model.UserName}' and keypass='{model.Keypass}'";
            var sqlcmd = new SqlCommand(query, dbconn.SqlConnection);
            var sqlresult = sqlcmd.ExecuteReader();
            if (sqlresult.HasRows)
            {
                status = true;
            }
            else
            {
                status = false;
            }
            dbconn.CloseConnection();
            return status;
        }
        private async Task UpdateDataAsync()
        {
            if (isValidating())
            {
                dbconn.OpenConnection();
                var state = check ? "1" : "0";
                var query = $"UPDATE users SET " +
                            $"name = '{model.Name}'," +
                            $"username = '{model.UserName}'," +
                            $"keypass = '{model.Keypass}'," +
                            $"status = '{state}'" +
                            $"WHERE uid = '{model.Uid}'";
                var sqlcmd = new SqlCommand(query, dbconn.SqlConnection);
                sqlcmd.ExecuteNonQuery();
                dbconn.CloseConnection();
                await ReadDataAsync();
            }
        }

        private async Task DeleteDataAsync()
        {
            if (isValidating())
            {
                var msg = MessageBox.Show("Are you sure?", "Question",
                          MessageBoxButton.YesNo, MessageBoxImage.Question);
                if (msg == MessageBoxResult.Yes)
                {
                    dbconn.OpenConnection();
                    var query = $"DELETE users " +
                                $"WHERE uid = '{model.Uid}'";
                    var sqlcmd = new SqlCommand(query, dbconn.SqlConnection);
                    sqlcmd.ExecuteNonQuery();
                    dbconn.CloseConnection();
                }

                await ReadDataAsync();

            }
        }


        private bool isValidating()
        {
            var flag = true;
            if (Model.Name == null)
            {
                MessageBox.Show("Name Cannot Empty", "Warning",
                    MessageBoxButton.OK,
                    MessageBoxImage.Exclamation);
            }
            return flag;
        }


    }
}


