﻿using System;
using System.Threading.Tasks;
using System.ComponentModel;
using System.Collections.ObjectModel;
using System.Data.SqlClient;
using System.Windows;
using FP.Setup;
using FP.Models;
using FP.View.Inventories;


namespace FP.ViewModel
{
    public class ProductViewModel : INotifyPropertyChanged
    {
        public ProductViewModel()
        {
            collection = new ObservableCollection<Product>();
            dbconn = new Db_Connection();
            model = new Product();
            //tproduct = new ProductView();


            SelectCommand = new RelayCommand(async () => await ReadDataAsync());
            UpdateCommand = new RelayCommand(async () => await UpdateDataAsync());
            DeleteCommand = new RelayCommand(async () => await DeleteDataAsync());
            BackupCommand = new RelayCommand(async () => await Backupdata());
            SelectCommand.Execute(null);

        }
        public RelayCommand SelectCommand { get; set; }
        public RelayCommand UpdateCommand { get; set; }
        public RelayCommand DeleteCommand { get; set; }
        public RelayCommand BackupCommand { get; set; }
        public ObservableCollection<Product> Collection
        {
            get
            {
                return collection;
            }
            set
            {
                collection = value;
                PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(null));
            }

        }

        public Product Model
        {
            get
            {
                return model;
            }
            set
            {
                if (value != null)
                {
                    IsChecked = (value.Status == "Active") ? true : false;
                }
                model = value;
                PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(null));
            }
        }
        public bool IsChecked
        {
            get
            {
                return check;
            }
            set
            {
                check = value;
                PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(null));

            }
        }



        public event PropertyChangedEventHandler PropertyChanged;
        public event Action OnCallBack;

        //public ProductView tproduct;
        private readonly Db_Connection dbconn;
        private ObservableCollection<Product> collection;
        private Product model;
        private bool check;

        private async Task ReadDataAsync()
        {
            dbconn.OpenConnection();

            await Task.Delay(0);
            var query = "SELECT * FROM products";
            var sqlcmd = new SqlCommand(query, dbconn.SqlConnection);
            var sqlresult = sqlcmd.ExecuteReader();

            if (sqlresult.HasRows)
            {
                Collection.Clear();
                while (sqlresult.Read())
                {
                    Collection.Add(new Product
                    {
                        Uid = sqlresult[0] as int? ?? 0,
                        Name = sqlresult[1].ToString(),
                        Status = (sqlresult[2].ToString() == "1") ?
                        "Active" : "Not Active",
                    });
                }
            }
            dbconn.CloseConnection();
            OnCallBack?.Invoke();
        }

        private async Task UpdateDataAsync()
        {
            if (isValidating())
            {
                dbconn.OpenConnection();
                var state = check ? "1" : "0";
                var query = $"UPDATE products SET " +
                            $"name = '{model.Name}'," +
                            $"status = '{state}'" +
                            $"WHERE uid = '{model.Uid}'";
                var sqlcmd = new SqlCommand(query, dbconn.SqlConnection);
                sqlcmd.ExecuteNonQuery();
                dbconn.CloseConnection();
                await ReadDataAsync();
            }
        }

        private async Task Backupdata()
        {
            if (isValidating())
            {
                dbconn.OpenConnection();
                var query = $"EXECUTE sp_backupdatabase";
                var sqlcmd = new SqlCommand(query, dbconn.SqlConnection);
                sqlcmd.ExecuteNonQuery();
                dbconn.CloseConnection();
                await ReadDataAsync();
            }
        }

        private async Task DeleteDataAsync()
        {
            if (isValidating())
            {
                var msg = MessageBox.Show("Are you sure?", "Question",
                          MessageBoxButton.YesNo, MessageBoxImage.Question);
                if (msg == MessageBoxResult.Yes)
                {
                    dbconn.OpenConnection();
                    var query = $"DELETE products " +
                                $"WHERE uid = '{model.Uid}'";
                    var sqlcmd = new SqlCommand(query, dbconn.SqlConnection);
                    sqlcmd.ExecuteNonQuery();
                    dbconn.CloseConnection();
                }
                await ReadDataAsync();
            }
        }


        private bool isValidating()
        {
            var flag = true;
            if (Model.Name == null)
            {
                MessageBox.Show("Name Cannot Empty", "Warning",
                    MessageBoxButton.OK,
                    MessageBoxImage.Exclamation);
            }
            return flag;
        }
    }
}


