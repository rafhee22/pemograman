﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FP.Models
{
    class UserRule
    {
        public string Uid { get; set; }
        public string User { get; set; }
        public string Menu { get; set; }
        public string Access { get; set; }
    }
}
