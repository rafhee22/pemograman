﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FP.Models
{
    public class User
    {
        public int Uid { get; set; }
        public string Name { get; set; }
        public string UserName { get; set; }
        public string Keypass { get; set; }
        public string Status { get; set; }
    }
}
