﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FP.Models
{
    class InventoryLog
    {
        public int Uid { get; set; }
        public string inventories { get; set; }
        public string Products { get; set; }
        public int Qty { get; set; }
    }
}
