﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;

namespace FP.Setup
{
    public class Db_Connection
    {
        public SqlConnection SqlConnection;
        public string SqlNotice;

        public Db_Connection()
        {
            SqlConnection = new SqlConnection();
            dbserver = @"LAPTOP-B8L8P8B9";
            dbname = "Retailer_DB";
        }

        public bool OpenConnection()
        {
            SqlConnection.ConnectionString =
                $"Server={dbserver};Database={dbname};Trusted_Connection=yes";
            SqlConnection.InfoMessage += Notice_Handler;
            SqlConnection.FireInfoMessageEventOnUserErrors = true;
            SqlConnection.Open();
            return true;

        }
        public bool CloseConnection()
        {
            SqlConnection.InfoMessage -= Notice_Handler;
            SqlConnection.Close();
            return true;
        }
        private readonly string dbserver;
        private readonly string dbname;

        private void Notice_Handler(object sender, SqlInfoMessageEventArgs e)
        {
            SqlNotice = e.Message;
        }
    }
}
