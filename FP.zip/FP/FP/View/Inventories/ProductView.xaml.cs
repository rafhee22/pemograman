﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using FP.ViewModel;

namespace FP.View.Inventories
{
    /// <summary>
    /// Interaction logic for ProductView.xaml
    /// </summary>
    public partial class ProductView : Window
    {
        public ProductView()
        {
            InitializeComponent();
            vm = new ProductViewModel();
            vm.OnCallBack += Close;
            DataContext = vm;
        }
        private readonly ProductViewModel vm;
        private void BtnUpdate_Click(object sender, RoutedEventArgs e)
        {
            TxtUid.IsEnabled = true;
            TxtName.IsEnabled = true;

            vm.Model = new Models.Product();
            vm.IsChecked = true;
            TxtName.Focus();
        }

        private void BtnEdit_Click(object sender, RoutedEventArgs e)
        {

        }

        private void BtnDelete_Click(object sender, RoutedEventArgs e)
        {
            Home.Dashboard dashboard = new Home.Dashboard();
            dashboard.Show();
            this.Close();
        }

        private void BtnReset_Click(object sender, RoutedEventArgs e)
        {

        }

        private void BtnClose_Click(object sender, RoutedEventArgs e)
        {
            Home.Dashboard dashboard = new Home.Dashboard();
            dashboard.Show();
            this.Close();
        }

        private void TblData_SelectedCellsChanged(object sender, SelectedCellsChangedEventArgs e)
        {

        }

        private void TblData_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {

        }

        private void BtnUpdate_Click_1(object sender, RoutedEventArgs e)
        {

        }
    }
}
