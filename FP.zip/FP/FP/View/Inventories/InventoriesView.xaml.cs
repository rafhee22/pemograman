﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using FP.ViewModel;
namespace FP.View.Inventories
{
    /// <summary>
    /// Interaction logic for InventoriesView.xaml
    /// </summary>
    public partial class InventoriesView : Window
    {
        public InventoriesView()
        {
            InitializeComponent();
            vm = new InventoryViewModel();
            vm.OnCallBack += Close;
            DataContext = vm;
        }
        private readonly InventoryViewModel vm;
        private void TblData_SelectedCellsChanged(object sender, SelectedCellsChangedEventArgs e)
        {

        }

        private void TblData_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {

        }

        private void BtnUpdate_Click(object sender, RoutedEventArgs e)
        {

        }

        private void BtnEdit_Click(object sender, RoutedEventArgs e)
        {

        }

        private void BtnDelete_Click(object sender, RoutedEventArgs e)
        {

        }

        private void BtnReset_Click(object sender, RoutedEventArgs e)
        {

        }

        private void BtnClose_Click(object sender, RoutedEventArgs e)
        {
            Home.Dashboard dashboard = new Home.Dashboard();
            dashboard.Show();
            this.Close();
        }

        private void TblDataInv_SelectedCellsChanged(object sender, SelectedCellsChangedEventArgs e)
        {

        }

        private void TblDataInv_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {

        }

        private void TblDataInv_SelectedCellsChanged_1(object sender, SelectedCellsChangedEventArgs e)
        {

        }

        private void TblDataInv_SelectionChanged_1(object sender, SelectionChangedEventArgs e)
        {

        }
    }
}
