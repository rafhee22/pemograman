﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using FP.ViewModel;
using FP.Models;

namespace FP.View.Home
{
    /// <summary>
    /// Interaction logic for LoginDialog.xaml
    /// </summary>
    public partial class LoginDialog : Window
    {
        public string username;
        public string password;
        private Dashboard Dashboard;

        public LoginDialog()
        {
            vm = new UserViewModel();
            InitializeComponent();
            vm.OnCallBack += Close;
            DataContext = vm;
        }

        private readonly UserViewModel vm;

        //public RelayCommand LoginCommand { get; set; }
        // LoginCommand = new RelayCommand(async () => await LoginDataAsync());

        private void TextBox_TextChanged(object sender, TextChangedEventArgs e)
        {

        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            vm.Model = new User
            {
                UserName = TxtUser.Text,
                Keypass = TxtPassword.Password
            };
            if (vm.Login())
            {
                Dashboard = new Dashboard();
                Dashboard.Show();
                this.Close();
            }
            else
            {
                Status.Visibility = Visibility.Visible;
            }
        }

        private void btnClose_Click(object sender, RoutedEventArgs e)
        {
            Home.Dashboard dashboard = new Home.Dashboard();
            dashboard.Show();
            this.Close();
        }

        private void TxtPassword_PasswordChanged(object sender, RoutedEventArgs e)
        {

        }
    }
}
