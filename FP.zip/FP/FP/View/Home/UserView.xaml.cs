﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using FP.ViewModel;

namespace FP.View.Home
{
    /// <summary>
    /// Interaction logic for UserView.xaml
    /// </summary>
    public partial class UserView : Window
    {
        public UserView()
        {
            InitializeComponent();
            vm = new UserViewModel();
            vm.OnCallBack += Close;
            DataContext = vm;
        }

        private readonly UserViewModel vm;

        private void TblData_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {

        }

        private void TblUser_SelectedCellsChanged(object sender, SelectedCellsChangedEventArgs e)
        {

        }

        private void TblUser_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {

        }

        private void BtnUpdate_Click(object sender, RoutedEventArgs e)
        {

        }

        private void BtnEdit_Click(object sender, RoutedEventArgs e)
        {

        }

        private void BtnDelete_Click(object sender, RoutedEventArgs e)
        {

        }

        private void BtnReset_Click(object sender, RoutedEventArgs e)
        {

        }

        private void BtnClose_Click(object sender, RoutedEventArgs e)
        {
            Home.Dashboard dashboard = new Home.Dashboard();
            dashboard.Show();
            this.Close();
        }

        private void BtnMenu_Click(object sender, RoutedEventArgs e)
        {

        }
    }
}
