﻿using System;

namespace CodeChallenge
{
    class Program
    {

        static void Main(string[] args)
        {
            Nasabah nasabah = new Nasabah.Builder("Ahmad Mabruri", 21113872, "-", "Lampung", "-", 0)
            .withOffice("JLN.Ir.Sutami Lampung Timur")
            .withPhoneNumber("088287277077")
            .withSallary(2500000)
            .build();

            nasabah.print();

            Console.WriteLine();

            Address address = new Address.Builder("1", "5", "Gunung Pasir Jaya", "Sekampung Udik", "Lampung Timur", "Lampung", "0", "0")
            .withStreet("Ir.Sutami")
            .withNote("Depan PT Fermentech Indonesia")
            .build();
            Console.Write("Alamat: ");

            address.print();
        }
    }
}